﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.Plugin.Program")]
[assembly: Guid("82f60d9a-9280-4b6a-8b21-f3c694cb7e1d")]