﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.Plugin.ControlPanel")]
[assembly: Guid("59141b10-8941-4e90-a0a6-bc9385a04cc6")]