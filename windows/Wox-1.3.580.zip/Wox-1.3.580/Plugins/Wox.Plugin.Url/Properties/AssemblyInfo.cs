﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.Plugin.Url")]
[assembly: Guid("ea42b60d-34ff-4656-8ee1-012afa397d3e")]