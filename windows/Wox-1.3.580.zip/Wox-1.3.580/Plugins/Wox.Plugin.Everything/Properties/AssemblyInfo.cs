﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.Plugin.Everything")]
[assembly: Guid("97f6ccd0-e9dc-4aa2-b4ce-6b9f14ea20a7")]