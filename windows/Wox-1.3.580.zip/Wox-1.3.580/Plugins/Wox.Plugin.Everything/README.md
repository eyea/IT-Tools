Wox.Plugin.Everything
=====================

Wox plugin for Everything
