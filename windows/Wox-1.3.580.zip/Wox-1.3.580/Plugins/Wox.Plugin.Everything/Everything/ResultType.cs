namespace Wox.Plugin.Everything.Everything
{
    public enum ResultType
    {
        Volume,
        Folder,
        File
    }
}