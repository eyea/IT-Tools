﻿using System;

namespace Wox.Plugin.Everything.Everything
{
    /// <summary>
    /// 
    /// </summary>
    public class RegisterClassExException : ApplicationException
    {
    }
}