using System;

namespace Wox.Plugin.Everything.Everything.Exceptions
{
    /// <summary>
    /// 
    /// </summary>
    public class MemoryErrorException : ApplicationException
    {
    }
}