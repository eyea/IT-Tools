﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.Plugin.Caculator")]
[assembly: Guid("ba698b90-59ed-4c2e-bce1-497eb2f9e76f")]