﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.Plugin.PluginIndicator")]
[assembly: Guid("27f6d9fc-340b-47be-90ea-2a86bfca7bad")]