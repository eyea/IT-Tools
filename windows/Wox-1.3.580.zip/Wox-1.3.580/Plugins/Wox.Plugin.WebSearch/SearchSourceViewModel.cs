﻿namespace Wox.Plugin.WebSearch
{
    public class SearchSourceViewModel
    {
        public SearchSource SearchSource { get; set; }
    }
}