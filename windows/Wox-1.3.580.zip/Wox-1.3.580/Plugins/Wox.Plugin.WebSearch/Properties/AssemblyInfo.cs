﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.Plugin.WebSearch")]
[assembly: Guid("42c17706-44ba-4549-ab66-7bd994706cd1")]