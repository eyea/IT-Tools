﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.Plugin.Folder")]
[assembly: Guid("e047418e-f7b0-4a3a-b855-0bef7178179f")]