﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.Plugin.CMD")]
[assembly: Guid("9283a32d-5d3c-4231-96e0-2150ed4716b9")]