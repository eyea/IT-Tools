﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.Plugin.Sys")]
[assembly: Guid("e1eecff6-3f25-424d-9bbd-cbd7d6e1e11e")]