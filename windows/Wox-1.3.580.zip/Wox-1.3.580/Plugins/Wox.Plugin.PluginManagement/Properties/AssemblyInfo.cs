﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.Plugin.PluginManagement")]
[assembly: Guid("92b59bab-5c8c-414b-a8d7-326c7be3a11d")]