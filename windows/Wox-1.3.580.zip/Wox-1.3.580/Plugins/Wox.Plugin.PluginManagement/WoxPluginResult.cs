namespace Wox.Plugin.PluginManagement
{
    public class WoxPluginResult
    {
        public string plugin_file;
        public string description;
        public int liked_count;
        public string name;
        public string version;
    }
}