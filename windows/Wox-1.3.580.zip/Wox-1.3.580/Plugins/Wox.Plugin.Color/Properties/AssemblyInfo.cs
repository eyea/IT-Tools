﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.Plugin.Color")]
[assembly: Guid("46b03f84-5bf7-4ed4-a69b-f0274c8b3776")]