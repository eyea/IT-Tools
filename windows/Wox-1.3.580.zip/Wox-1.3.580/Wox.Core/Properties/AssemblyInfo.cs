﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.Core")]
[assembly: Guid("693aa0e5-741b-4759-b740-fdbb011a3280")]