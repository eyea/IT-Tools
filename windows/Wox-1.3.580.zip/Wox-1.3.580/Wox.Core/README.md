﻿What does Wox.Core do?
=====

* Handle Query
* Define Wox exceptions
* Manage Plugins (including system plugin and user plugin)
* Manage Themes
* Manage i18n
* Manage Update and version