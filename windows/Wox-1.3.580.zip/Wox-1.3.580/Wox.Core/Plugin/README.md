﻿There are two kinds of plugins:
1. System plugin
	Those plugins that action keyword is "*", those plugin doesn't need action keyword
2. User Plugin
	Those plugins that contains customized action keyword