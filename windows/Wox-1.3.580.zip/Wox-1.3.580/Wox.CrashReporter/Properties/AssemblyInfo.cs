﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.CrashReporter")]
[assembly: Guid("0ea3743c-2c0d-4b13-b9ce-e5e1f85aea23")]