﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.Infrastructure")]
[assembly: Guid("aee57a31-29e5-4f03-a41f-7917910fe90f")]
[assembly: InternalsVisibleTo("Wox")]
[assembly: InternalsVisibleTo("Wox.Core")]
[assembly: InternalsVisibleTo("Wox.Test")]