﻿using System.Reflection;
using System.Windows;

[assembly: AssemblyTitle("Wox")]
[assembly: ThemeInfo(
    ResourceDictionaryLocation.None, 
    ResourceDictionaryLocation.SourceAssembly
)]