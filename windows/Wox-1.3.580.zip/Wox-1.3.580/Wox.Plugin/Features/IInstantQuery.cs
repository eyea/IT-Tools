﻿using System;

namespace Wox.Plugin.Features
{
    [Obsolete("Delete Wox.Plugin.Features using directive, " +
              "and use Wox.Plugin.Feature.IInstantQuery instead, " +
              "this method will be removed in v1.3.0")]
    public interface IInstantQuery { }
}