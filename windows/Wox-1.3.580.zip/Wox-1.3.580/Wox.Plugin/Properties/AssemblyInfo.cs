﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.Plugin")]
[assembly: Guid("c22be00d-a6f5-4e45-8ecc-09ebf297c812")]
[assembly: InternalsVisibleTo("Wox")]
[assembly: InternalsVisibleTo("Wox.Core")]
[assembly: InternalsVisibleTo("Wox.Test")]
