﻿What does Wox.Plugin do?
====

* Define base objects and interfaces for plugins
* Plugin Author who making C# plugin should reference this DLL via nuget