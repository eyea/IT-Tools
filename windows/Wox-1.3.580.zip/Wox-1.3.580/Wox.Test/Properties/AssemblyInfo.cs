﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Wox.Test")]
[assembly: Guid("c42c2b1b-ead4-498c-a06d-7cbde85760e4")]